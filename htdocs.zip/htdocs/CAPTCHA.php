<!DOCTYPE html>
<html>
<body>
<form method="Post">
    <input type="hidden" name="Email" value="<?php echo isset($Email) ? $Email : ''; ?>">
    <input type="text" name="verification_code" placeholder="Enter your verification code" required />
    <input type="submit" name="verify_email" value="Verify Email">
</form>
<?php
session_start();
if (isset($_POST['verify_email'])) {
    $Email = $_POST['Email'];
    $input_verification = $_POST['verification_code'];
    // Connect to the database
    $conn = mysqli_connect("localhost:3306", "root", "", "id21562751_requests");
//mark email as verifid
    $statementss = $conn->prepare("UPDATE systemuser SET email_verified_at = NOW() WHERE Email =  ?  AND verification_code =  ? ");
    $statementss->bind_param("ss", $Email, $input_verification);
    $statementss->execute();
    $statementss->close();
    $conn->close();
    header("Location:index.php");
    if (mysqli_affected_rows($conn) == 0) {
        die("Verification code failed.");
    }
    echo"<p>You can login now.</p>";
    exit();
}
?>

</body>
</html>
