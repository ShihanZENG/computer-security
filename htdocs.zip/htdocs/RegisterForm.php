<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-form {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 700px; /* 增加表单宽度 */
        }
        .form-field {
            margin-bottom: 15px;
        }
        .form-field label {
            display: inline-block;
            width: 240px;
            text-align: right;
            padding-right: 15px;
            font-size: 16px;
        }
        .form-field input {
            width: 240px;
            padding: 10px;
            font-size: 16px;
        }
        input[type='submit'] {
            width: auto;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #0056b3;
            color: white;
            border: none;
            border-radius: 5px;
        }
        input[type='submit']:hover {
            background-color: #004494;
        }
    </style>
</head>

<body>
<div class="register-form">
        <form action='RegisterFormCheck.php' method='POST'>
            <h1>Please register your details below:</h1>
            <div class="form-field">
                <label>Type in your Contact Telephone Number:</label>
                <input name='ContactTelephoneNumber' type='text' required />
            </div>
            <div class="form-field">
                <label>Type in your Username:</label>
                <input name='Username' type='text' required />
            </div>
            <div class="form-field">
                <label>Type in your Email address:</label>
                <input name='Email' type='email' required />
            </div>
            <div class="form-field">
                <label>Type in your password:</label>
                <input name='Password' type='password' required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" />
                <br>
                <small>(Password should be at least 8 characters long, including at least one uppercase letter, one lowercase letter, one number, and one special character).</small>
            </div>
            <input type='hidden' name='csrf_token' value='<?php echo $csrfToken; ?>'/>
            <div class="form-field">
                <input type='submit' name='register' value='Register' class="submit-button">
            </div>
            <div class="register-link">
                <p>Already have an account? <a href="index.php">Click here</a></p>
                <p>forgotten password? <a href="Forgotpasswordform.php">Click here</a></p>
            </div>
        </form>
    </div>
</body>
</html>
