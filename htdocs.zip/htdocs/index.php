<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// echo "CSRF Token in Login Page: " . $_SESSION['csrf_token'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>recaptcha </title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
        }
        .form-container {
            text-align: center;
        }
        .form-title {
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
        }
        form {
            border: 1px solid #ddd;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.2);
            border-radius: 8px;
        }
        input[type="text"], input[type="password"] {
            margin-bottom: 10px;
            width: 200px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px 0;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .register-link {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-title"> Lovejoy’s Antique Login</div>
        <form action="LoginScript.php" method="post">
            <div class="g-recaptcha" data-sitekey="6LdVVS8pAAAAAMQA7bIR7zLa-HCl6v6_kLX-Nnvh"></div>
            Username: <input type="text" name="Username"><br>
            Password: <input type="password" name="Password"><br>
            <input type="submit" name="login" value="Submit">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        </form>
        <div class="register-link">
            <p>Don't have an account? <a href="RegisterForm.php">Register here</a></p>
            <p>forgotten password? <a href="Forgotpasswordform.php">Click here</a></p>    
        </div>
    </div>
</body>
</html>
