<?php
// Database connection
$connection = new mysqli('localhost', 'root', '', 'id21562751_requests');
if (!$connection) {
    die("Could not connect to the server: " . mysqli_connect_error());
}

if (isset($_POST['newPassword'], $_POST['confirmPassword'], $_POST['token'])) {
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];
    $token = $_POST['token'];

    if ($newPassword == $confirmPassword) {
        // Verify the token and its validity
        $stmt = $connection->prepare("SELECT ID FROM systemuser  WHERE reset_token = ? AND token_expiration > NOW()");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Update password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $connection->prepare("UPDATE systemuser  SET Password = ?, reset_token = NULL, token_expiration = NULL WHERE reset_token = ?");
            $updateStmt->bind_param("ss", $hashedPassword, $token);
            $updateStmt->execute();

            echo "Your password has been updated.";
            echo "<br><a href='index.php'>Click here to return to the homepage</a>";
        } else {
            echo "Invalid or expired token.";
        }
    } else {
        echo "Passwords do not match.";
    }
}
?>
