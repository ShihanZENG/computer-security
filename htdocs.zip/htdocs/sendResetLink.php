//sendResetLink.php
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Database connection
$connection = mysqli_connect('localhost', 'root', '', 'id21562751_requests');
if (!$connection) {
    die("Could not connect to the server: " . mysqli_connect_error());
}
// Check if the mailbox exists
if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $stmt = $connection->prepare("SELECT ID FROM systemuser WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        // Generate a reset token
        $token = bin2hex(random_bytes(32));
        // Store the token and its expiry time
        $updateStmt = $connection->prepare("UPDATE systemuser SET reset_token = ?, token_expiration = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE Email = ?");
        $updateStmt->bind_param("ss", $token, $email);
        $updateStmt->execute();
        // Introducing the PHPMailer class
        require 'PHPMailer-master/src/Exception.php';
        require 'PHPMailer-master/src/PHPMailer.php';
        require 'PHPMailer-master/src/SMTP.php';
        $mail = new PHPMailer(true);
        try {
            // Configuring PHPMailer
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'zhenshihan24@gmail.com';
            $mail->Password = 'ifdy awxn xiym kpwp';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            // Setting up recipients
            $mail->setFrom('zhenshihan24@gmail.com', 'Password Reset');
            $mail->addAddress($email);
            // Setting the content of the message
            $mail->isHTML(true);
            $mail->Subject = 'Reset your password';
            $resetLink = "http://localhost/resetPassword.php?token=" . $token;
            $mail->Body = "Please click on the following link to reset your password: <a href='" . $resetLink . "'>" . $resetLink . "</a>";
            // Send mail
            $mail->send();
            echo "A password reset link has been sent to your email.";
        } catch (Exception $e) {
            echo "Mail cannot be sent. Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Email does not exist.";
    }
}
?>
