//Database.php
<?php
class Database {
    private $host = "localhost";
    private $database_name = "id21562751_requests";
    private $username = "root";
    private $password = "";
    private $connection;

    public function __construct() {
        $this->connection = $this->connect();
    }

    private function connect() {
        try {
            return new mysqli($this->host, $this->username, $this->password, $this->database_name);
        } catch (mysqli_sql_exception $exception) {
            die("Connection error: " . $exception->getMessage());
        }
    }

    public function getConnection() {
        return $this->connection;
    }
}

?>
