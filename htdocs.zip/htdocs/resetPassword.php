<form action="resetPasswordScript.php" method="post">
    New Password: <input type="password" name="newPassword" required>
    Confirm Password: <input type="password" name="confirmPassword" required>
    <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">
    <input type="submit" value="Reset Password">
</form>
