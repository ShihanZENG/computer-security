<?php
// RegisterFormCheck.php
session_start();
// Set error reporting level to display all errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
$mysql_host = "localhost";
$mysql_database = "id21562751_requests";
$mysql_user = "root";
$mysql_password = "";
// Establish a connection to the database or display an error message
$connection = mysqli_connect($mysql_host, $mysql_user, $mysql_password, $mysql_database) or die("Could not connect to the server");
// Check if form data is set
if (!isset($_POST['Username'], $_POST['Password'])) {
    exit('Please fill both the username and password fields!');
}
// Generate CSRF tokens
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// 设置错误报告级别以显示所有错误
ini_set('display_errors', 1);
error_reporting(E_ALL);

$csrfToken = $_SESSION['csrf_token'];

// CSRF Token Authentication
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF token validation failed');
    }
}
// Check if form data is set
if (!isset($_POST['Username'], $_POST['Password'])) {
    exit('Please fill both the username and password fields!');
}

// Fetching form data and cleaning and escaping it to prevent SQL injection and XSS attacks
$username = mysqli_real_escape_string($connection, trim($_POST['Username']));
$ContactTelephoneNumber = mysqli_real_escape_string($connection, trim($_POST['ContactTelephoneNumber']));
$email = mysqli_real_escape_string($connection, trim($_POST['Email']));
$password = mysqli_real_escape_string($connection, $_POST['Password']);
$username = htmlspecialchars($username);
$ContactTelephoneNumber = htmlspecialchars($ContactTelephoneNumber);
$email = htmlspecialchars($email);
$password = htmlspecialchars($password);

// Password strength check: make sure it contains at least one uppercase letter, one lowercase letter, one number, one special character, and is at least 8 characters long
$uppercase = preg_match('@[A-Z]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$number = preg_match('@[0-9]@', $password);
$specialChars = preg_match('@[^\w]@', $password);
if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
    exit("Password should be at least 8 characters in length and should include at least one uppercase letter, one number, and one special character. <a href='RegisterForm.php'>Click to return to the registration form</a>");
}

// Ensure that the length of the input does not exceed the database limit
if (strlen($username) > 20 || strlen($ContactTelephoneNumber) > 20 || strlen($email) > 30 || strlen($password) > 30) {
    exit("One of the inputs you have entered has exceeded the maximum character length. Please revise this! <a href='RegisterForm.php'>Click to return to the registration form</a>");
}
// Initialize error flag
$errorOccurred = 0;
// Check if ContactTelephoneNumber is blank
if (empty($ContactTelephoneNumber)) {
    echo "ContactTelephoneNumber was blank!<br/>";
    $errorOccurred = 1;
}
// Check if Username is blank
if (empty($username)) {
    echo "Username was blank! <br/>";
    $errorOccurred = 1;
}
// Check if Email is not provided
if (empty($email)) {
    echo "Email not provided<br/>";
    $errorOccurred = 1;
}
// Database query: check if the username already exists
$stmt = $connection->prepare('SELECT id, Password FROM systemuser WHERE username = ?');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo "The username has already been used!<br/>";
    $errorOccurred = 1;
}
// Check if the Email address already exists
$result = mysqli_query($connection, "SELECT * FROM systemuser WHERE Email = '$email'");
if (mysqli_num_rows($result) > 0) {
    echo "This email address has already been used.<br/>";
    $errorOccurred = 1;
}
// Retrieve user information from the database
if ($stmt->num_rows > 0) {
    $stmt->bind_result($id, $password);
    $stmt->fetch();
    $stmt->close(); // 在fetch之后关闭stmt对象
    // Verify the password
    if (password_verify($_POST['Password'], $password)) { 
        // Verification success! User has logged in!
        // Create sessions to remember user data on the server
        session_regenerate_id();
        $_SESSION['register'] = TRUE;
        $_SESSION['name'] = $username; // Use the right variables
        $_SESSION['id'] = $id;
        echo 'Welcome ' . $_SESSION['name'] . '!';
    } else {
        // Incorrect password
        echo 'Incorrect username and/or password!';
    }
} else {
    // Incorrect username
    echo 'Incorrect username and/or password!';
}

// Check if username already exists and increment the error flag
if ($result->num_rows > 0) {
    echo "The username has already been used!<br/>";
    $errorOccurred = 1;
}
$sendEmail = true; // Initialize a boolean flag for sending email
// Check if any errors occurred during validation
if ($errorOccurred > 0) {
    echo "Validation failed. Please fix the errors and try again.";
    // Close the database connection
    mysqli_close($connection);
    // Terminate the program
    exit;
}
// Insert user details into the database if no errors occurred
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$stmt = $connection->prepare("INSERT INTO systemuser (Username, Password, ContactTelephoneNumber, Email) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $username, $hashedPassword, $ContactTelephoneNumber, $email);
if ($stmt->execute()) {
    echo "Thank you for joining the Computer Security network<br/>";
} else {
    echo "Error: " . $stmt->error;
}
$stmt->close();
// Send verification email
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
$mail = new PHPMailer(true);
try {
    // SMTP configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'zhenshihan24@gmail.com';
    $mail->Password = 'ifdy awxn xiym kpwp';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    // Recipients
    $mail->setFrom('zhenshihan24@gmail.com', 'TEST');
    $mail->addAddress($email, $username);
    // Content
    $mail->isHTML(true);
    $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
    $mail->Subject = 'Email verification';
    $mail->Body = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</b></p>';
    $mail->send();
    echo 'Mail has been sent';
    // Update user with verification code
    $stmt = $connection->prepare("UPDATE systemuser SET verification_code = ? WHERE Username = ?");
    $stmt->bind_param("ss", $verification_code, $username);
    $stmt->execute();
    $stmt->close();
    header("Location: CAPTCHA.php");
    exit;
} catch (Exception $e) {
    echo "Mail cannot be sent. Error: {$mail->ErrorInfo}";
}
// Close connection
$connection->close();
?>
