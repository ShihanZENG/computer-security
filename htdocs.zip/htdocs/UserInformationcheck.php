<?php
session_start(); // Start the session
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ...
    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
        // user_id is set, continue
    } else {
        // If user_id is not set, print a debug message.
        error_log("Session user_id is not set. Current session: " . print_r($_SESSION, true));
        die("User ID is not set in session.");
    }
}
// Functions to connect to the database
function connectToDatabase() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "id21562751_requests"; // Database name
    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Functions that handle file uploads
function uploadFile($file) {
    $targetDirectory = "uploads/"; // Destination folder
    // If the directory does not exist, create
    if (!file_exists($targetDirectory)) {
        mkdir($targetDirectory, 0777, true);
    }
    $filename = basename($file["name"]);
    $targetFilePath = $targetDirectory . $filename;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'png', 'jpeg', 'gif']; // Allowed file types
    $maxSize = 5 * 1024 * 1024; // File size limit 5MB
    // Check the file type and size
    if (!in_array($fileType, $allowedTypes) || $file["size"] > $maxSize) {
        return false;
    }
    // Move files to the destination folder
    if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
        return $targetFilePath;
    } else {
        return "";
    }   
}

// Get user submissions from the database
function getUserSubmissions($conn, $userId) {
    $stmt = $conn->prepare("SELECT title, description, details, contact_method, image_path FROM systemuser WHERE ID = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $submissions = [];
    while ($row = $result->fetch_assoc()) {
        $submissions[] = $row;
    }
    $stmt->close();
    return $submissions;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = connectToDatabase();
    // Receive form data
    $title = mysqli_real_escape_string($conn, trim($_POST['title']));
    $description = mysqli_real_escape_string($conn, trim($_POST['description']));
    $details = isset($_POST['details']) ? mysqli_real_escape_string($conn, trim($_POST['details'])) : '';
    $contactPreference = mysqli_real_escape_string($conn, trim($_POST['contact_preference']));
    // Handle file uploads
    $imagePath = uploadFile($_FILES['fileToUpload']);
    if ($imagePath === false) {
        echo "File upload failed. Please check the file type and size.";
        exit;
    }

    // Check form data integrity
    if (!$title || !$description || !$details) {
        die("Please fill in all required fields.");
    } else {
        // Check if the user ID is set
        if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
            $userId = $_SESSION['user_id'];
            // Update the database with the user ID
            $stmt = $conn->prepare("UPDATE systemuser SET title = ?, description = ?, details = ?, contact_method = ?, image_path = ? WHERE ID = ?");
            $stmt->bind_param("sssssi", $title, $description, $details, $contactPreference, $imagePath, $userId);
            if ($stmt->execute()) {
                echo "Your request has been submitted successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            die("User ID is not set in session.");
        }
    }
    $conn->close();
}

// If it's a GET request, display the information submitted by the user
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_SESSION['user_id'])) {
        $conn = connectToDatabase();
        $userId = $_SESSION['user_id'];
        $submissions = getUserSubmissions($conn, $userId);
        $conn->close();
        // Display user-submitted information
        foreach ($submissions as $submission) {
            echo "<div>";
            echo "<h3>" . htmlspecialchars($submission['title']) . "</h3>";
            echo "<p>" . htmlspecialchars($submission['description']) . "</p>";
            // More fields can be displayed here...
            echo "</div>";
        }
    } else {
        echo "Please login to view your submissions.";
    }
}
?>
