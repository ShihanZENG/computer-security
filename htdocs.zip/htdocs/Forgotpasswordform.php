<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>forgotten password</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .forgot-password-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="email"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        input[type="submit"] {
            background-color: #0056b3;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #004494;
        }
    </style>
</head>
<body>
    <div class="forgot-password-container">
        <h2>forgotten password</h2>
        <p>Please enter your email address and we will send you instructions to reset your password</p>
        <form action="sendResetLink.php" method="post">
            <input type="email" name="email" placeholder="Please enter your email address" required>
            <input type="submit" value="Reset Password">
        </form>
    </div>
</body>
</html>
