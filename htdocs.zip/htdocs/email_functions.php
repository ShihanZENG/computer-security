<?php
session_start();
// email_functions.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once 'PHPMailer-master/src/Exception.php';
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';

function sendPasswordResetEmail($recipientEmail, $resetLink, $username = 'User') {
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 0; // Disable Debugging in production
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'zhenshihan24@gmail.com'; // SMTP username
        $mail->Password = 'ifdy awxn xiym kpwp'; // SMTP password
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('zhenshihan24@gmail.com', 'TEST');
        $mail->addAddress($recipientEmail, $username);
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request';
        $mail->Body = "<p>To reset your password, please click on the following link: <a href='" . $resetLink . "'>" . $resetLink . "</a></p><p>If you did not request a password reset, please ignore this email.</p>";

        if ($mail->send()) {
            return true;
        } else {
            return false;
        }
    } catch (Exception $e) {
        // Log the error
        error_log("Mailer Error: " . $e->getMessage());
        return false;
    }
}
?>
