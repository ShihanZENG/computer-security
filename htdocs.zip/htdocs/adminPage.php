<?php
session_start();
// 检查用户是否登录且为管理员
// if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
//     header('Location: index.php');
//     exit;
// }
// 数据库连接
$servername = "localhost";
$rootUser = "root";
$db = "id21562751_requests";
$rootPassword = "";
$con = new mysqli($servername, $rootUser, $rootPassword, $db);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql = "SELECT Username, Email, title, description, details, contact_method, image_path FROM systemuser"; // 调整查询以包含您想要展示的字段
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - User Submissions</title>
    <!-- CSS -->
</head>
<body>
    <h2>User Submissions</h2>
    <table>
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Title</th>
            <th>Description</th>
            <th>Details</th>
            <th>Contact Method</th>
            <th>Image</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["Username"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Email"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["title"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["description"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["details"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["contact_method"]) . "</td>";
                echo "<td><img src='" . htmlspecialchars($row["image_path"]) . "' height='100'></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No submissions found</td></tr>";
        }
        ?>
    </table>
</body>
</html>
<?php
$con->close();
?>
