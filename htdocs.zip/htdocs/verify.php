<?php
session_start();
if (isset($_POST['verification_code']) && isset($_POST['email1'])) {
    $input_verification_code = $_POST['verification_code'];
    $email = $_POST['email1'];
    // Connect to the database
    $servername = "localhost";
    $rootUser = "root";
    $db = "id21562751_requests";
    $rootPassword = "";
    $connection = mysqli_connect($servername, $rootUser, $rootPassword, $db);
    if (!$connection) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    // Query the database for user information
    $sql = "SELECT verification_code FROM systemuser WHERE Email1 = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("s", $email1); // Assuming $email is the email address submitted by the user
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $user_verification_code = $row['verification_code'];

        if ($input_verification_code === $user_verification_code) {
            header("Location: index.php");
            exit;
        } else {
            $delete_stmt = $connection->prepare("DELETE FROM systemuser WHERE Email1 = ?");
            $delete_stmt->bind_param("s", $email);
            $delete_stmt->execute();
            echo "<script>alert('Verification code is incorrect. Please try again.'); window.location.href='RegisterForm.php';</script>";
            exit;
        }
        } else {
            echo "<script>alert('No record found for this email. Please register again.'); window.location.href='RegisterForm.php';</script>";
            exit;
        }
            $stmt->close();
            $connection->close();
        } else {
            header("Location: RegisterForm.php");
            exit;
        }

?>
