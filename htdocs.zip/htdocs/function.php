<?php
// Database connection configuration, modify these values according to your database configuration
$servername = "localhost";  
$username = "root";         
$password = "";            
$dbname = "id21562751_requests"; 
// Creating a Database Connection
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
/**
 * :: Checking the number of login attempts and lockout status
 *
 * @param mysqli $con Database Connection Objects
 * @param string $username user ID
 * @param int $maxAttempts Maximum number of attempts allowed
 * @param int $lockoutTime Account lockout time (in seconds)
 * @return bool Returns whether login attempts are allowed
 */
function checkLoginAttempts($con, $username, $maxAttempts, $lockoutTime) {
    // Query the database for the number of login attempts and the last attempt time.
    $stmt = $con->prepare("SELECT login_attempts, last_attempt_time FROM systemuser WHERE Username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($loginAttempts, $lastAttemptTime);
    $stmt->fetch();
    $stmt->close();

    // Check if the maximum number of attempts has been exceeded
    if ($loginAttempts >= $maxAttempts) {
        // Check if the lock time has elapsed since the last attempt
        $currentTime = time();
        $lastAttemptUnixTime = strtotime($lastAttemptTime);
        $timeDiff = $currentTime - $lastAttemptUnixTime;

        if ($timeDiff <= $lockoutTime) {
            return false; // The account should be locked.
        }
    }
    return true; // Account is not locked
}

function generateCsrfToken() {
    // Generate and store CSRF tokens
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function validateCsrfToken() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            // 令牌验证失败
            return false;
        }
    }
    return true;
}