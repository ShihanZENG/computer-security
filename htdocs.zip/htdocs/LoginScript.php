//LoginScript.php
<?php
session_start();
echo "CSRF Token in LoginScript: " . $_SESSION['csrf_token'];
require_once 'Database.php';
require_once 'function.php';

$db = new Database();
$con = $db->getConnection();

if ($con->connect_error) {
    die("Connection error: " . $con->connect_error);
}

// Form submission processing
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check for the existence of a CSRF token
    if (!isset($_POST['csrf_token'])) {
        die('CSRF token is missing.');
    }

    // Verify that the CSRF token in the session matches the one submitted with the form
    if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // If the token does not match, reject the request
        die('CSRF token validation failed.');
    }
    
if (isset($_POST['Username'], $_POST['Password'], $_POST['g-recaptcha-response'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF token validation failed!');
    }
}
unset($_SESSION['csrf_token']);
}

// reCAPTCHA secret key
$secretKey = "6LdVVS8pAAAAAL8Lpc_3-u0MEmo_uWE-IPyIy_f9";

// Check if the form was submitted
if (isset($_POST['Username'], $_POST['Password'], $_POST['g-recaptcha-response'])) {
    $username = filter_input(INPUT_POST, 'Username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'Password', FILTER_SANITIZE_STRING);
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // reCAPTCHA response
    $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
    $response = file_get_contents($verifyUrl . "?secret=" . $secretKey . "&response=" . $recaptchaResponse);
    $responseData = json_decode($response);
    if (!$responseData->success) {
        echo 'reCAPTCHA verification failed, please try again.';
        exit;
    }

    // Login Attempts Check
    $maxAttempts = 2;
    $lockoutTime = 60; // 5 minutes
    // Assuming checkLoginAttempts() function is defined elsewhere
    if (!checkLoginAttempts($con, $username, $maxAttempts, $lockoutTime)) {
        exit('Your account has been temporarily locked due to multiple failed login attempts.');
    }

    // SQL Query and User Authentication
    $stmt = $con->prepare('SELECT id, Password, role FROM systemuser WHERE Username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashedPassword, $role);
        $stmt->fetch();

        if (password_verify($password, $hashedPassword)) {
            // Successful login
            $_SESSION['loggedin'] = TRUE;
            $_SESSION['user_id'] = $id;
            $_SESSION['name'] = $username;
            $_SESSION['role'] = $role;

            // Reset attempts after successful login
            $stmt = $con->prepare("UPDATE systemuser SET login_attempts = 0, last_attempt_time = NULL WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->close();

            if ($role === 'admin') {
                header("Location: adminPage.php");
                exit();
            } else {
                header("Location: UserInformationform.php");
                exit();
            }
        } else {
             // Incorrect username and/or password, increase login_attempts here
            $stmt = $con->prepare("UPDATE systemuser SET login_attempts = login_attempts + 1 WHERE Username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            echo 'Incorrect username and/or password!';
        }
    } else {
         // Incorrect username and/or password, increase login_attempts here
        $stmt = $con->prepare("UPDATE systemuser SET login_attempts = login_attempts + 1 WHERE Username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        echo 'This account will be locked for one minute.';
    }
} else {
    echo 'Please fill both the username and password fields and complete the reCAPTCHA!';
}


$con->close();
?>


$stmt = $con->prepare("UPDATE systemuser SET login_attempts = login_attempts + 1 WHERE Username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();