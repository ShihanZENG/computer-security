// Google reCAPTCHA
grecaptcha.ready(function() {
    grecaptcha.execute('6LfINi4pAAAAAKJxkxy3bst4sI-06QMW0ukvd_wX', {action: 'login'}).then(
        function(token) {
            var response = document.getElementById('token_generate');
            response.value = token;
        }
    );
});
// 检查消息并显示
document.addEventListener("DOMContentLoaded", function() {
    var message = document.getElementById('message');
    if (message && message.innerText) {
        alert(message.innerText);
    }
});
