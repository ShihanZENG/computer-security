//UserInformationform.php
<?php
session_start(); 
// Handling file upload
// $uploadedFilePath = '';
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fileToUpload'])) {
//     $targetDirectory = "uploads/";
//     $uploadedFileName = basename($_FILES['fileToUpload']['name']);
//     $uploadedFilePath = $targetDirectory . $uploadedFileName;

//     // Add file validation here (file type, size, etc.)

//     // Attempt to move the uploaded file to the target directory
//     if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $uploadedFilePath)) {
//         // File is successfully uploaded
//         // Process the file here if needed
//     } else {
//         // Handle error
//         $uploadedFilePath = ''; // Reset if failed
//     }
$uploadedFilePath = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fileToUpload'])) {
    $targetDirectory = "uploads/";
    $uploadedFileName = basename($_FILES['fileToUpload']['name']);
    $uploadedFilePath = $targetDirectory . $uploadedFileName;
    // File validation
    // Check file size (e.g., max 5MB)
    if ($_FILES['fileToUpload']['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    $imageFileType = strtolower(pathinfo($uploadedFilePath,PATHINFO_EXTENSION));
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // Attempt to move the uploaded file to the target directory
    } else {
        if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $uploadedFilePath)) {
            // File is successfully uploaded
            // Process the file here if needed
        } else {
            // Handle error
            echo "Sorry, there was an error uploading your file.";
            $uploadedFilePath = ''; // Reset if failed
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Antique Appraisal Request</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: 'Nunito', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            height: 100vh;
            background-color: #eaeaea;
        }

        .form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 6px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
            overflow: auto; 
        }

        .title {
            font-size: 24px;
            color: #333;
            font-weight: 700;
            margin-bottom: 15px;
            text-align: left;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type=text], textarea, input[type=file] {
            padding: 15px;
            margin-bottom: 15px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type=submit] {
            background-color: #007bff;
            color: white;
            padding: 15px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 700;
        }

        input[type=submit]:hover {
            background-color: #0056b3;
        }

        .register-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
        }

        .image-preview {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px;
            text-align: center;
            display: none; /* Initially hidden */
        }

        .image-preview img {
            max-width: 100%;
            height: auto;
        }
        .contact-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }
        
        .contact-icons input[type="radio"] {
            display: none;
        }

        .contact-icons label {
             font-size: 24px;
             color: #007bff;
             cursor: pointer;
        }

        .contact-icons input[type="radio"]:checked + label {
        color: #0056b3;
        }
        
                .contact-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }
        
        .contact-icons input[type="radio"] {
            display: none;
        }

        .contact-icons label {
            font-size: 24px;
            color: #007bff;
            cursor: pointer;
        }

        .contact-icons input[type="radio"]:checked + label {
            color: #0056b3;
        }
    </style>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    
</head>
<body>
    <div class="form-container">
        <div class="title">Antique Appraisal Request</div>
        <!-- Main form -->
        <form action="UserInformationcheck.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm();">
            <!-- Form fields -->
            <input type="text" name="title" id="title" placeholder="Title" required>
            <textarea name="description" id="description" placeholder="Description" required></textarea>
            <textarea name="details" id="comments" placeholder="Details of the object and request" required></textarea>  
            <h3 class="contact-header">Preferred Contact Method</h3>           
            <select name="contact_preference" id="contact_preference" required>
                <option value="phone">Phone</option>
                <option value="email">Email</option>
            </select>
            <!-- File upload input -->
            <h4 class="contact-header">Please upload pictures</h4>
            <input type="file" name="fileToUpload" id="fileToUpload" onchange="previewImage();" required>
            <!-- Display uploaded image if available -->
            <?php if ($uploadedFilePath): ?>
                <div class="image-preview">
                    <img src="<?php echo htmlspecialchars($uploadedFilePath); ?>" alt="Uploaded Image">
                </div>
            <?php endif; ?>
            <!-- Submit button -->
            <input type="submit" value="Submit Request">
        </form>
        <!-- Registration link -->
        <div class="register-link"> 
            <p>Don't have an account? <a href="RegisterForm.php">Register here</a></p>
            <p>View your submitted information <a href="userPage.php">here</a>.</p>
        </div>
    </div>
    <!-- JavaScript for form validation and image preview -->
    <script>
        function validateForm() {
            // Validation logic here
            // Example: Validate title and description
            var title = document.getElementById('title').value;
            var description = document.getElementById('description').value;
            if (!title || !description) {
                alert("Title and description are required");
                return false;
            }
            return true;
        }
        function previewImage() {
            var preview = document.getElementById('imagePreview');
            var file = document.getElementById('fileToUpload').files[0];
            var reader = new FileReader();
            reader.onloadend = function() {
                if (preview) {
                    preview.style.display = 'block';
                    preview.innerHTML = '<img src="' + reader.result + '" alt="Image preview" />';
                }
            }
            if (file) {
                reader.readAsDataURL(file);
            } else {
                if (preview) {
                    preview.style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>
